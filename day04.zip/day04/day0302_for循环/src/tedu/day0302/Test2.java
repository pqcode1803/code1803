package tedu.day0302;

public class Test2 {
	public static void main(String[] args) {
		for(int i=1;i<=3;i++) {
			for(int j=10;j>=7;j--) {
				System.out.println(i+", "+j);
			}
		}
	}
}
